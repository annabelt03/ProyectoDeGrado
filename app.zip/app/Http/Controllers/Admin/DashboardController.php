<?php

namespace App\Http\Controllers\Admin;

use App\Models\Usuario;
use App\Models\Producto;
use App\Models\Registro;
use App\Models\RegistroCanjeo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        // Verificar el rol del usuario
        $usuario = auth()->user();
        
        if ($usuario->role === 'administrador') {
            return $this->adminDashboard($request);
        } elseif ($usuario->role === 'estudiante') {
            return $this->estudianteDashboard($request);
        }
        
        abort(403, 'Acceso no autorizado');
    }

    /**
     * Dashboard para Administradores
     */
    private function adminDashboard(Request $request)
    {
        // Estadísticas generales de usuarios
        $totalUsuarios = Usuario::count();
        $estudiantesActivos = Usuario::where('role', 'estudiante')
                                   ->where('estado', 'activo')
                                   ->count();
        $totalAdministradores = Usuario::where('role', 'administrador')->count();
        $usuariosInactivos = Usuario::where('estado', '!=', 'activo')->count();
        $usuariosRecientes = Usuario::latest()->take(5)->get();

        // Estadísticas de productos
        $totalProductos = Producto::count();
        $productosActivos = Producto::where('activo', true)->count();
        $productosStockBajo = Producto::where('stock', '<=', 5)->count();
        $productosAgotados = Producto::where('stock', 0)->count();

        // Estadísticas de canjes
        $totalCanjes = RegistroCanjeo::count();
        $canjesHoy = RegistroCanjeo::whereDate('fecha_canjeo', today())->count();
        $puntosCanjeadosHoy = RegistroCanjeo::whereDate('fecha_canjeo', today())->sum('puntos_totales');
        $puntosCanjeadosTotal = RegistroCanjeo::sum('puntos_totales');

        // Estados de canjes
        $estadosCanjes = RegistroCanjeo::selectRaw('estado, count(*) as total')
                                ->groupBy('estado')
                                ->get();

        // Top productos más canjeados
        $topProductos = RegistroCanjeo::selectRaw('producto_id, count(*) as total_canjes, sum(cantidad) as total_unidades')
                               ->with('producto')
                               ->groupBy('producto_id')
                               ->orderBy('total_canjes', 'desc')
                               ->limit(5)
                               ->get();

        // Últimos canjes
        $ultimosCanjes = RegistroCanjeo::with(['usuario', 'producto'])
                                ->orderBy('fecha_canjeo', 'desc')
                                ->limit(5)
                                ->get();

        return view('auth.admin.dashboard', compact(
            'totalUsuarios',
            'estudiantesActivos',
            'totalAdministradores',
            'usuariosInactivos',
            'usuariosRecientes',
            'totalProductos',
            'productosActivos',
            'productosStockBajo',
            'productosAgotados',
            'totalCanjes',
            'canjesHoy',
            'puntosCanjeadosHoy',
            'puntosCanjeadosTotal',
            'estadosCanjes',
            'topProductos',
            'ultimosCanjes'
        ));
    }

    /**
     * Dashboard para Estudiantes
     */
    private function estudianteDashboard(Request $request)
    {
        $usuario = auth()->user();
        
        $estadisticas = [
            'totalCanjes' => RegistroCanjeo::where('usuario_id', $usuario->id)->count(),
            'canjesPendientes' => RegistroCanjeo::where('usuario_id', $usuario->id)
                                         ->where('estado', 'canjeado')
                                         ->count(),
            'canjesEntregados' => RegistroCanjeo::where('usuario_id', $usuario->id)
                                         ->where('estado', 'entregado')
                                         ->count(),
            'totalPuntosCanjeados' => RegistroCanjeo::where('usuario_id', $usuario->id)
                                             ->sum('puntos_totales'),
        ];

        // Últimos canjes
        $ultimosCanjes = RegistroCanjeo::with('producto')
                                ->where('usuario_id', $usuario->id)
                                ->orderBy('fecha_canjeo', 'desc')
                                ->limit(5)
                                ->get();

        // Productos recomendados (que puede canjear)
        $productosRecomendados = Producto::where('activo', true)
                                        ->where('stock', '>', 0)
                                        ->where('puntos_valor', '<=', $usuario->puntos)
                                        ->orderBy('puntos_valor', 'asc')
                                        ->limit(4)
                                        ->get();

        return view('dashboard.estudiante', compact(
            'usuario', 
            'estadisticas', 
            'ultimosCanjes', 
            'productosRecomendados'
        ));
    }

    /**
     * Estadísticas avanzadas para admin (opcional)
     */
    public function estadisticasAvanzadas(Request $request)
    {
        // Solo para administradores
        if (auth()->user()->role !== 'administrador') {
            abort(403, 'No autorizado');
        }

        $rango = $request->get('range', 'week');
        
        // Lógica para estadísticas por rango de tiempo
        $canjesPorMes = $this->getCanjesPorMes($rango);
        $topRecolectores = $this->getTopRecolectores($rango);
        $productosPopulares = $this->getProductosPopulares($rango);

        return view('dashboard.estadisticas', compact(
            'canjesPorMes',
            'topRecolectores',
            'productosPopulares',
            'rango'
        ));
    }

    private function getCanjesPorMes($rango)
    {
        $query = RegistroCanjeo::selectRaw('YEAR(fecha_canjeo) as year, MONTH(fecha_canjeo) as month, COUNT(*) as total');
        
        if ($rango === 'week') {
            $query->where('fecha_canjeo', '>=', now()->subWeek());
        } elseif ($rango === 'month') {
            $query->where('fecha_canjeo', '>=', now()->subMonth());
        }
        
        return $query->groupBy('year', 'month')
                    ->orderBy('year', 'desc')
                    ->orderBy('month', 'desc')
                    ->get();
    }

    private function getTopRecolectores($rango)
    {
        $query = Usuario::where('role', 'estudiante')
                       ->withCount(['registros as total_puntos' => function($query) use ($rango) {
                           if ($rango === 'week') {
                               $query->where('fecha_canjeo', '>=', now()->subWeek());
                           } elseif ($rango === 'month') {
                               $query->where('fecha_canjeo', '>=', now()->subMonth());
                           }
                           $query->select(DB::raw('COALESCE(SUM(puntos_totales), 0)'));
                       }])
                       ->orderBy('total_puntos', 'desc')
                       ->limit(10);

        return $query->get();
    }

    private function getProductosPopulares($rango)
    {
        $query = Producto::withCount(['registros as total_canjes' => function($query) use ($rango) {
                        if ($rango === 'week') {
                            $query->where('fecha_canjeo', '>=', now()->subWeek());
                        } elseif ($rango === 'month') {
                            $query->where('fecha_canjeo', '>=', now()->subMonth());
                        }
                    }])
                    ->orderBy('total_canjes', 'desc')
                    ->limit(10);

        return $query->get();
    }
}