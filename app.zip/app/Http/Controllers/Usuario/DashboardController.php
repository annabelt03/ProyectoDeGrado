<?php
// app/Http/Controllers/Usuario/DashboardController.php
namespace App\Http\Controllers\Usuario;

use App\Http\Controllers\Controller;

class DashboardController extends Controller
{
    public function index()
    {
        // Para el estudiante, usamos los datos del usuario autenticado
        return view('estudiante.dashboard');
    }
}
