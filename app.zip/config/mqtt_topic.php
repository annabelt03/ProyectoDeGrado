<?php
return [
    'ecorecicla' => env('MQTT_TOPIC_ECORECICLA', 'ecorecicla/lecturas'),
];
