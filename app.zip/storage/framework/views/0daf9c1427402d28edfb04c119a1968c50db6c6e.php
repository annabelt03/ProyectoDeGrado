

<?php $__env->startSection('title', 'Mis Canjes'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-md-8">
            <h2>Mis Canjes</h2>
            <p class="text-muted">Historial de todos tus canjes realizados</p>
        </div>
        <div class="col-md-4 text-end">
            <a href="<?php echo e(route('estudiante.productos')); ?>" class="btn btn-primary">
                <i class="fas fa-gift"></i> Canjear Productos
            </a>
        </div>
    </div>

    <!-- Estadísticas -->
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card bg-light">
                <div class="card-body">
                    <div class="row text-center">
                        <div class="col-md-3">
                            <h4 class="text-primary"><?php echo e($totalPuntosCanjeados); ?></h4>
                            <p class="mb-0 text-muted">Total Puntos Canjeados</p>
                        </div>
                        <div class="col-md-3">
                            <h4 class="text-warning"><?php echo e($canjes->total()); ?></h4>
                            <p class="mb-0 text-muted">Total Canjes</p>
                        </div>
                        <div class="col-md-3">
                            <h4 class="text-success"><?php echo e($canjes->where('estado', 'entregado')->count()); ?></h4>
                            <p class="mb-0 text-muted">Entregados</p>
                        </div>
                        <div class="col-md-3">
                            <h4 class="text-info"><?php echo e($canjes->where('estado', 'canjeado')->count()); ?></h4>
                            <p class="mb-0 text-muted">Pendientes</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Filtros -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('estudiante.mis-canjes')); ?>">
                <div class="row g-3">
                    <div class="col-md-4">
                        <label for="estado" class="form-label">Estado</label>
                        <select class="form-select" id="estado" name="estado">
                            <option value="">Todos los estados</option>
                            <option value="canjeado" <?php echo e(request('estado') == 'canjeado' ? 'selected' : ''); ?>>Canjeado</option>
                            <option value="entregado" <?php echo e(request('estado') == 'entregado' ? 'selected' : ''); ?>>Entregado</option>
                            <option value="cancelado" <?php echo e(request('estado') == 'cancelado' ? 'selected' : ''); ?>>Cancelado</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label for="fecha_desde" class="form-label">Fecha desde</label>
                        <input type="date" class="form-control" id="fecha_desde" name="fecha_desde" 
                               value="<?php echo e(request('fecha_desde')); ?>">
                    </div>
                    <div class="col-md-3">
                        <label for="fecha_hasta" class="form-label">Fecha hasta</label>
                        <input type="date" class="form-control" id="fecha_hasta" name="fecha_hasta" 
                               value="<?php echo e(request('fecha_hasta')); ?>">
                    </div>
                    <div class="col-md-2 d-flex align-items-end">
                        <div class="d-grid w-100">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-filter"></i> Filtrar
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Lista de Canjes -->
    <div class="card">
        <div class="card-body">
            <?php if($canjes->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Producto</th>
                                <th>Fecha</th>
                                <th>Cantidad</th>
                                <th>Puntos</th>
                                <th>Estado</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $canjes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $canje): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <?php if($canje->producto->imagen): ?>
                                                <img src="<?php echo e(asset('storage/' . $canje->producto->imagen)); ?>" 
                                                     alt="<?php echo e($canje->producto->nombreProducto); ?>" 
                                                     class="rounded me-3" 
                                                     style="width: 40px; height: 40px; object-fit: cover;">
                                            <?php else: ?>
                                                <div class="rounded bg-light me-3 d-flex align-items-center justify-content-center" 
                                                     style="width: 40px; height: 40px;">
                                                    <i class="fas fa-image text-muted"></i>
                                                </div>
                                            <?php endif; ?>
                                            <div>
                                                <strong><?php echo e($canje->producto->nombreProducto); ?></strong>
                                                <br>
                                                <small class="text-muted"><?php echo e(Str::limit($canje->producto->descripcion, 30)); ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo e($canje->fecha_canjeo->format('d/m/Y H:i')); ?></td>
                                    <td><?php echo e($canje->cantidad); ?></td>
                                    <td>
                                        <span class="badge bg-primary"><?php echo e($canje->puntos_totales); ?></span>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo e($canje->estado == 'entregado' ? 'success' : ($canje->estado == 'cancelado' ? 'danger' : 'warning')); ?>">
                                            <?php echo e(ucfirst($canje->estado)); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('estudiante.ver-canje', $canje->id)); ?>" 
                                           class="btn btn-sm btn-outline-primary">
                                            <i class="fas fa-eye"></i> Ver
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <!-- Paginación -->
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <div>
                        Mostrando <?php echo e($canjes->firstItem()); ?> a <?php echo e($canjes->lastItem()); ?> de <?php echo e($canjes->total()); ?> canjes
                    </div>
                    <?php echo e($canjes->links()); ?>

                </div>
            <?php else: ?>
                <div class="text-center py-5">
                    <i class="fas fa-history fa-3x text-muted mb-3"></i>
                    <h4>No hay canjes registrados</h4>
                    <p class="text-muted">Aún no has realizado ningún canje de productos.</p>
                    <a href="<?php echo e(route('estudiante.productos')); ?>" class="btn btn-primary">
                        <i class="fas fa-gift"></i> Realizar primer canje
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.estudiante.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecorecicla\resources\views/estudiante/mis-canjes.blade.php ENDPATH**/ ?>