

<?php $__env->startSection('title','Iniciar Sesión Admin - EcoRecicla PET'); ?>

<?php $__env->startSection('content'); ?>
<div class="card shadow border-0" style="max-width:420px;margin:0 auto">
  <div class="card-body p-4">
    <h4 class="mb-3"><i class="fas fa-user-shield me-2 text-success"></i> Iniciar Sesión (Admin)</h4>

   <!-- <form method="POST" action="<?php echo e(route('loginAdmin.attempt')); ?>"><?php echo csrf_field(); ?>
      <div class="mb-3">
        <label class="form-label">Correo electrónico</label>
        <input type="email" name="email" class="form-control" required autofocus value="<?php echo e(old('email')); ?>">
      </div>
      <div class="mb-3">
        <label class="form-label">Contraseña</label>
        <input type="password" name="password" class="form-control" required>
      </div>

      <?php if($errors->any()): ?>
        <div class="alert alert-danger py-2"><?php echo e($errors->first()); ?></div>
      <?php endif; ?>

      <button class="btn btn-success w-100">Entrar</button>
    </form>-->
    <form method="POST" action="<?php echo e(route('loginAdmin.attempt')); ?>">
  <?php echo csrf_field(); ?>
  <div class="mb-3">
    <label for="email">Correo</label>
    <input id="email" name="email" type="email" value="<?php echo e(old('email')); ?>" required autofocus>
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>

  <div class="mb-3">
    <label for="password">Contraseña</label>
    <input id="password" name="password" type="password" required>
    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>

  <div class="form-check mb-3">
    <input class="form-check-input" type="checkbox" id="remember" name="remember">
    <label class="form-check-label" for="remember">Recordarme</label>
  </div>

  <button type="submit">Iniciar sesión</button>
</form>

  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Web3\2025-Proyecto\2025-Proyecto\ecorecicla\resources\views/auth/loginAdmin.blade.php ENDPATH**/ ?>