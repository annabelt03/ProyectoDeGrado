

<?php $__env->startSection('title', 'Lista de Productos'); ?>
<?php $__env->startSection('header', 'Lista de Productos'); ?>

<?php $__env->startSection('actions'); ?>
    <a href="<?php echo e(route('admin.productos.create')); ?>" class="btn btn-primary">
        <i class="fas fa-plus"></i> Nuevo Producto
    </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Filtros -->
<div class="card mb-4">
    <div class="card-header">
        <h5 class="mb-0"><i class="fas fa-filter"></i> Filtros</h5>
    </div>
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('admin.productos.index')); ?>">
            <div class="row g-3">
                <div class="col-md-3">
                    <label for="nombre" class="form-label">Nombre</label>
                    <input type="text" class="form-control" id="nombre" name="nombre" 
                           value="<?php echo e(request('nombre')); ?>" placeholder="Buscar por nombre...">
                </div>
                <div class="col-md-2">
                    <label for="puntos_min" class="form-label">Puntos Mín.</label>
                    <input type="number" class="form-control" id="puntos_min" name="puntos_min" 
                           value="<?php echo e(request('puntos_min')); ?>" min="0">
                </div>
                <div class="col-md-2">
                    <label for="puntos_max" class="form-label">Puntos Máx.</label>
                    <input type="number" class="form-control" id="puntos_max" name="puntos_max" 
                           value="<?php echo e(request('puntos_max')); ?>" min="0">
                </div>
                <div class="col-md-2">
                    <label for="stock_min" class="form-label">Stock Mín.</label>
                    <input type="number" class="form-control" id="stock_min" name="stock_min" 
                           value="<?php echo e(request('stock_min')); ?>" min="0">
                </div>
                <div class="col-md-2">
                    <label for="activo" class="form-label">Estado</label>
                    <select class="form-select" id="activo" name="activo">
                        <option value="">Todos</option>
                        <option value="1" <?php echo e(request('activo') == '1' ? 'selected' : ''); ?>>Activo</option>
                        <option value="0" <?php echo e(request('activo') == '0' ? 'selected' : ''); ?>>Inactivo</option>
                    </select>
                </div>
                <div class="col-md-1 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search"></i>
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Tabla de productos -->
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Productos (<?php echo e($productos->total()); ?>)</h5>
        <a href="<?php echo e(route('admin.productos.create')); ?>" class="btn btn-black btn-sm">
            <i ></i>+ Nuevo Producto 
        </a>
    </div>
    <div class="card-body">
        <?php if($productos->count() > 0): ?>
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>Imagen</th>
                            <th>Nombre</th>
                            <th>Descripción</th>
                            <th>Puntos</th>
                            <th>Stock</th>
                            <th>Estado</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php if($producto->imagen): ?>
                                        <img src="<?php echo e(asset('storage/' . $producto->imagen)); ?>" 
                                             alt="<?php echo e($producto->nombreProducto); ?>" 
                                             class="producto-img img-thumbnail " style="width: 30px">
                                    <?php else: ?>
                                        <div class="text-center text-muted">
                                            <i class="fas fa-image fa-2x"></i>
                                            <br><small>Sin imagen</small>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($producto->nombreProducto); ?></td>
                                <td><?php echo e(Str::limit($producto->descripcion, 50)); ?></td>
                                <td>
                                    <span class="badge bg-primary"><?php echo e($producto->puntos_valor); ?></span>
                                </td>
                                <td>
                                    <?php if($producto->stock <= 5): ?>
                                        <span class="badge bg-danger badge-stock"><?php echo e($producto->stock); ?></span>
                                    <?php elseif($producto->stock <= 10): ?>
                                        <span class="badge bg-warning badge-stock"><?php echo e($producto->stock); ?></span>
                                    <?php else: ?>
                                        <span class="badge bg-success badge-stock"><?php echo e($producto->stock); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($producto->activo): ?>
                                        <span class="badge bg-success">Activo</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Inactivo</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <a href="<?php echo e(route('admin.productos.show', $producto->id)); ?>" 
                                           class="btn btn-info btn-sm" title="Ver">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="<?php echo e(route('admin.productos.edit', $producto->id)); ?>" 
                                           class="btn btn-warning btn-sm" title="Editar">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <form action="<?php echo e(route('admin.productos.toggle-status', $producto->id)); ?>" 
                                              method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>
                                            <button type="submit" class="btn btn-<?php echo e($producto->activo ? 'secondary' : 'success'); ?> btn-sm" 
                                                    title="<?php echo e($producto->activo ? 'Desactivar' : 'Activar'); ?>">
                                                <i class="fas fa-<?php echo e($producto->activo ? 'times' : 'check'); ?>"></i>
                                            </button>
                                        </form>
                                        <form action="<?php echo e(route('admin.productos.destroy', $producto->id)); ?>" 
                                              method="POST" class="d-inline"
                                              onsubmit="return confirm('¿Estás seguro de eliminar este producto?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm" title="Eliminar">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <!-- Paginación -->
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    Mostrando <?php echo e($productos->firstItem()); ?> a <?php echo e($productos->lastItem()); ?> de <?php echo e($productos->total()); ?> resultados
                </div>
                <?php echo e($productos->links()); ?>

            </div>
        <?php else: ?>
            <div class="text-center py-5">
                <i class="fas fa-box-open fa-3x text-muted mb-3"></i>
                <h4>No se encontraron productos</h4>
                <p class="text-muted">No hay productos que coincidan con los criterios de búsqueda.</p>
                <a href="<?php echo e(route('admin.productos.create')); ?>" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Crear Primer Producto
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Web3\2025-Proyecto\2025-Proyecto\ecorecicla\resources\views/productos/index.blade.php ENDPATH**/ ?>