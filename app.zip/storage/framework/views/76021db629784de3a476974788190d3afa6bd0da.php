<?php $__env->startSection('title', 'Dashboard - Estudiante'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Header -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Mi Dashboard</h1>
        <div class="badge badge-success p-2">
            <i class="fas fa-circle fa-sm"></i> Estudiante Activo
        </div>
    </div>

    <!-- Información Personal -->
    <div class="row">
        <!-- Perfil del Estudiante -->
        <div class="col-lg-4 mb-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Mi Perfil</h6>
                </div>
                <div class="card-body text-center">
                    <div class="mb-3">
                        <i class="fas fa-user-graduate fa-3x text-primary"></i>
                    </div>
                    <h5 class="font-weight-bold"><?php echo e(auth()->user()->nombre); ?> <?php echo e(auth()->user()->primerApellido); ?></h5>
                    <p class="text-muted">Estudiante</p>

                    <div class="mt-3 text-left">
                        <p><strong><i class="fas fa-id-card"></i> RFID:</strong> <?php echo e(auth()->user()->numeroRFID); ?></p>
                        <p><strong><i class="fas fa-venus-mars"></i> Género:</strong>
                            <?php if(auth()->user()->genero == 'm'): ?>
                                Masculino
                            <?php elseif(auth()->user()->genero == 'f'): ?>
                                Femenino
                            <?php else: ?>
                                No especificado
                            <?php endif; ?>
                        </p>
                        <?php if(auth()->user()->fechaNacimiento): ?>
                        <p><strong><i class="fas fa-birthday-cake"></i> Fecha Nac.:</strong>
                            <?php echo e(\Carbon\Carbon::parse(auth()->user()->fechaNacimiento)->format('d/m/Y')); ?>

                        </p>
                        <?php endif; ?>
                        <p><strong><i class="fas fa-star"></i> Puntos:</strong>
                            <span class="badge badge-warning"><?php echo e(auth()->user()->puntos); ?></span>
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Puntos y Estado -->
        <div class="col-lg-4 mb-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Mis Puntos</h6>
                </div>
                <div class="card-body text-center">
                    <div class="mb-3">
                        <i class="fas fa-star fa-3x text-warning"></i>
                    </div>
                    <h1 class="display-4 font-weight-bold text-warning"><?php echo e(auth()->user()->puntos); ?></h1>
                    <p class="text-muted">Puntos acumulados</p>

                    <div class="mt-4">
                        <div class="progress mb-2">
                            <div class="progress-bar bg-warning" role="progressbar"
                                 style="width: <?php echo e(min(auth()->user()->puntos, 100)); ?>%"
                                 aria-valuenow="<?php echo e(auth()->user()->puntos); ?>"
                                 aria-valuemin="0"
                                 aria-valuemax="100">
                            </div>
                        </div>
                        <small class="text-muted">Progreso de puntos</small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Acciones Rápidas -->
        <div class="col-lg-4 mb-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Acciones Disponibles</h6>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <button class="btn btn-outline-primary btn-block mb-2">
                            <i class="fas fa-qrcode"></i> Escanear Código
                        </button>
                        <button class="btn btn-outline-success btn-block mb-2">
                            <i class="fas fa-gift"></i> Canjear Puntos
                        </button>
                        <button class="btn btn-outline-info btn-block mb-2">
                            <i class="fas fa-history"></i> Mi Historial
                        </button>
                        <button class="btn btn-outline-secondary btn-block mb-2">
                            <i class="fas fa-user-edit"></i> Editar Perfil
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Información Adicional -->
    <div class="row">
        <div class="col-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Bienvenido al Sistema</h6>
                </div>
                <div class="card-body">
                    <div class="text-center">
                        <i class="fas fa-graduation-cap fa-2x text-primary mb-3"></i>
                        <h4>¡Hola, <?php echo e(auth()->user()->nombre); ?>!</h4>
                        <p class="lead">Bienvenido a tu panel de estudiante. Aquí puedes gestionar tus puntos y actividades.</p>

                        <div class="row mt-4">
                            <div class="col-md-3 mb-3">
                                <div class="border rounded p-3">
                                    <i class="fas fa-check-circle fa-2x text-success mb-2"></i>
                                    <h6>Estado Activo</h6>
                                    <small class="text-muted">Cuenta activa</small>
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="border rounded p-3">
                                    <i class="fas fa-shield-alt fa-2x text-info mb-2"></i>
                                    <h6>Acceso RFID</h6>
                                    <small class="text-muted">Acceso por código</small>
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="border rounded p-3">
                                    <i class="fas fa-trophy fa-2x text-warning mb-2"></i>
                                    <h6>Acumula Puntos</h6>
                                    <small class="text-muted">Gana puntos</small>
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="border rounded p-3">
                                    <i class="fas fa-calendar-alt fa-2x text-primary mb-2"></i>
                                    <h6>Miembro desde</h6>
                                    <small class="text-muted"><?php echo e(auth()->user()->created_at->format('M Y')); ?></small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.estudiante.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\2025-Proyecto\2025-Proyecto\ecorecicla\resources\views/estudiante/dashboard.blade.php ENDPATH**/ ?>