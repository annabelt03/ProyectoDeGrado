
<?php $__env->startSection('title','Iniciar Sesión - EcoRecicla PET'); ?>

<?php $__env->startSection('content'); ?>
<div class="card shadow border-0" style="max-width:420px;margin:0 auto">
  <div class="card-body p-4 text-center">
   ,<!--  <h4 class="mb-4">
      <i class="fas fa-recycle me-2 text-success"></i>
      Iniciar Sesión
    </h4>-->

    <form method="POST" action="<?php echo e(route('login.attempt')); ?>"><?php echo csrf_field(); ?>
      <div class="mb-3 text-start">
        <label class="form-label fw-semibold"> Ingrese su Código RFID (8 caracteres)</label>
        <input
          type="text"
          name="numeroRFID"
          class="form-control text-uppercase text-center"
          maxlength="8"
          minlength="8"
          pattern="[0-9A-Fa-f]{8}"
          placeholder="Ej: 239E4CF5"
          required
          autofocus
          value="<?php echo e(old('numeroRFID')); ?>"
        >
        <div class="form-text">Solo letras (A–F) y números (0–9), exactamente 8 caracteres.</div>
      </div>

      <?php if($errors->any()): ?>
        <div class="alert alert-danger py-2"><?php echo e($errors->first()); ?></div>
      <?php endif; ?>

      <button type="submit" class="btn btn-success w-100">
        Iniciar sesión
      </button>
      <br><br>
       <a href="<?php echo e(route('loginAdmin')); ?>" class="btn btn-outline-success w-100 mt-2">
                Sesión Admin
                </a>

    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\2025-Proyecto\2025-Proyecto\ecorecicla\resources\views/auth/login.blade.php ENDPATH**/ ?>