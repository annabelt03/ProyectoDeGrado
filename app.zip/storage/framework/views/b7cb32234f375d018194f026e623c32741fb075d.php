 

<?php $__env->startSection('title', 'Dashboard Estudiante - EcoRecicla'); ?>
<?php $__env->startSection('header', 'Dashboard Estudiante'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <h2>Bienvenido, <?php echo e($usuario->nombre); ?> <?php echo e($usuario->primerApellido); ?></h2>
        <p class="text-muted">Tus puntos disponibles: <strong><?php echo e($usuario->puntos); ?></strong></p>
    </div>
</div>

<!-- Estadísticas -->
<div class="row mt-4">
    <div class="col-md-3">
        <div class="card bg-primary text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4><?php echo e($estadisticas['totalCanjes']); ?></h4>
                        <p>Total Canjes</p>
                    </div>
                    <div class="align-self-center">
                        <i class="fas fa-shopping-cart fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-warning text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4><?php echo e($estadisticas['canjesPendientes']); ?></h4>
                        <p>Pendientes</p>
                    </div>
                    <div class="align-self-center">
                        <i class="fas fa-clock fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-success text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4><?php echo e($estadisticas['canjesEntregados']); ?></h4>
                        <p>Entregados</p>
                    </div>
                    <div class="align-self-center">
                        <i class="fas fa-check-circle fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-info text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4><?php echo e($estadisticas['totalPuntosCanjeados']); ?></h4>
                        <p>Puntos Canjeados</p>
                    </div>
                    <div class="align-self-center">
                        <i class="fas fa-coins fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row mt-4">
    <!-- Productos Recomendados -->
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Productos que puedes canjear</h5>
            </div>
            <div class="card-body">
                <?php if($productosRecomendados->count() > 0): ?>
                    <div class="row">
                        <?php $__currentLoopData = $productosRecomendados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6 mb-3">
                                <div class="card h-100">
                                    <?php if($producto->imagen): ?>
                                        <img src="<?php echo e(asset('storage/' . $producto->imagen)); ?>" 
                                             class="card-img-top" 
                                             alt="<?php echo e($producto->nombreProducto); ?>"
                                             style="height: 150px; object-fit: cover;">
                                    <?php else: ?>
                                        <div class="text-center py-4 bg-light">
                                            <i class="fas fa-image fa-2x text-muted"></i>
                                        </div>
                                    <?php endif; ?>
                                    <div class="card-body">
                                        <h6 class="card-title"><?php echo e($producto->nombreProducto); ?></h6>
                                        <p class="card-text small text-muted">
                                            <?php echo e(Str::limit($producto->descripcion, 50)); ?>

                                        </p>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <span class="badge bg-primary"><?php echo e($producto->puntos_valor); ?> puntos</span>
                                            <span class="badge bg-success"><?php echo e($producto->stock); ?> disponibles</span>
                                        </div>
                                    </div>
                                    <div class="card-footer">
                                        <a href="<?php echo e(route('estudiante.ver-producto', $producto->id)); ?>" 
                                           class="btn btn-primary btn-sm w-100">
                                            Canjear
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <div class="text-center py-4">
                        <i class="fas fa-gift fa-3x text-muted mb-3"></i>
                        <p>No hay productos disponibles que puedas canjear con tus puntos actuales.</p>
                        <a href="<?php echo e(route('estudiante.productos')); ?>" class="btn btn-primary">
                            Ver Todos los Productos
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Últimos Canjes -->
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Tus últimos canjes</h5>
            </div>
            <div class="card-body">
                <?php if($ultimosCanjes->count() > 0): ?>
                    <div class="list-group list-group-flush">
                        <?php $__currentLoopData = $ultimosCanjes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $canje): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="list-group-item">
                                <div class="d-flex w-100 justify-content-between">
                                    <h6 class="mb-1"><?php echo e($canje->producto->nombreProducto); ?></h6>
                                    <small class="text-muted"><?php echo e($canje->fecha_canjeo->format('d/m')); ?></small>
                                </div>
                                <p class="mb-1 small">Cantidad: <?php echo e($canje->cantidad); ?></p>
                                <div class="d-flex justify-content-between">
                                    <span class="badge bg-primary"><?php echo e($canje->puntos_totales); ?> pts</span>
                                    <span class="badge bg-<?php echo e($canje->estado == 'entregado' ? 'success' : ($canje->estado == 'cancelado' ? 'danger' : 'warning')); ?>">
                                        <?php echo e(ucfirst($canje->estado)); ?>

                                    </span>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="mt-3 text-center">
                        <a href="<?php echo e(route('estudiante.mis-canjes')); ?>" class="btn btn-outline-primary btn-sm">
                            Ver todos los canjes
                        </a>
                    </div>
                <?php else: ?>
                    <div class="text-center py-4">
                        <i class="fas fa-history fa-2x text-muted mb-3"></i>
                        <p class="text-muted">Aún no has realizado ningún canje.</p>
                        <a href="<?php echo e(route('estudiante.productos')); ?>" class="btn btn-primary">
                            Realizar primer canje
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.estudiante.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecorecicla\resources\views/estudiante/dashboard.blade.php ENDPATH**/ ?>