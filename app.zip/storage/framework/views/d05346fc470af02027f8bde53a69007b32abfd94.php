<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>EcoRecicla PET - Inicio</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<style>
:root{--primary-green:#047656;--light-green:#4ddc9f;--accent-green:#16a34a}
html,body{height:100%;margin:0;font-family:Poppins,system-ui,sans-serif;color:#fff;
background:linear-gradient(135deg,var(--primary-green),var(--light-green));background-attachment:fixed}
.navbar{background:rgba(0,0,0,.3);backdrop-filter:blur(8px)}
.navbar-brand{color:#fff!important;font-weight:700;font-size:1.6rem;letter-spacing:1px}
.btn-outline-light{border-radius:20px;border-width:2px;color:#fff;border-color:#fff;font-weight:500;transition:.3s}
.btn-outline-light:hover{background-color:var(--accent-green);border-color:var(--accent-green)}
.btn-light{border-radius:20px;background-color:var(--accent-green);color:#fff;font-weight:600;transition:.3s}
.btn-light:hover{background:#12833a}
.carousel{max-width:950px;margin:60px auto;border-radius:25px;overflow:hidden;box-shadow:0 8px 20px rgba(0,0,0,.3)}
.carousel-item img{border-radius:25px;height:480px;object-fit:cover;opacity:.88;filter:brightness(.9)}
.carousel-caption{background:rgba(0,0,0,.55);border-radius:15px;padding:20px;color:#fff}
footer{text-align:center;color:#fff;padding:20px;opacity:.9}
</style>
</head>
<body>
<nav class="navbar navbar-expand-lg fixed-top">
<div class="container-fluid px-4">
<a class="navbar-brand" href="#"><i class="fas fa-recycle me-2"></i> EcoRecicla PET</a>
<div class="ms-auto">
<a href="<?php echo e(route('welcome')); ?>" class="btn btn-outline-light me-2">Inicio</a>
<a href="#" class="btn btn-outline-light me-2">Quiénes somos</a>
<a href="#" class="btn btn-outline-light me-2">Productos</a>
<a href="#" class="btn btn-light me-2">Contactos</a>
<a href="<?php echo e(route('login')); ?>" class="btn btn-outline-light me-2">Iniciar Sesión</a>
<!-- <a href="" class="btn btn-light">Iniciar Sesión Admin</a>-->
</div>
</div>
</nav>


<div style="margin-top:90px"></div>


<div id="carouselInfo" class="carousel slide" data-bs-ride="carousel">
<div class="carousel-inner">
<div class="carousel-item active">
</html><?php /**PATH D:\--------\2025-Proyecto\ecorecicla\resources\views/welcome.blade.php ENDPATH**/ ?>