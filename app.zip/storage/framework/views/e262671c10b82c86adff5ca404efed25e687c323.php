<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title><?php echo $__env->yieldContent('title','EcoRecicla PET — Estudiante'); ?></title>

  
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

  <style>
    :root{
      --primary: #10b981;
      --primary-dark: #0d9c6e;
      --primary-light: #d1fae5;
      --secondary: #f59e0b;
      --accent: #3b82f6;
      --background: #f0fdf4;
      --card-bg: #ffffff;
      --text: #1f2937;
      --text-muted: #6b7280;
      --border: #e5e7eb;
    }

    html,body{height:100%; margin:0; padding:0}
    body{background:var(--background); color:var(--text); font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;}

    .student-layout{
      display:grid;
      grid-template-columns: 280px 1fr;
      min-height:100vh;
    }

    /* SIDEBAR ESTUDIANTE */
    .student-sidebar{
      background: linear-gradient(180deg, var(--primary) 0%, var(--primary-dark) 100%);
      color:white;
      padding:20px 16px;
      position:sticky;
      top:0;
      height:100vh;
      box-shadow: 2px 0 10px rgba(0,0,0,0.1);
      display: flex;
      flex-direction: column;
    }

    .student-brand{
      display:flex;
      gap:12px;
      align-items:center;
      font-weight:700;
      color:white;
      text-decoration:none;
      font-size:1.3rem;
      margin-bottom:10px;
      padding:10px;
      border-radius:12px;
      background:rgba(255,255,255,0.1);
    }

    .student-brand i{
      font-size:1.5rem;
      color:#d1fae5;
    }

    /* USER INFO TOP */
    .user-info-top {
      background: rgba(255,255,255,0.15);
      border-radius: 12px;
      padding: 12px;
      margin-bottom: 20px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      border: 1px solid rgba(255,255,255,0.2);
    }

    .user-details {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .user-avatar {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      background: white;
      display: flex;
      align-items: center;
      justify-content: center;
      color: var(--primary);
      font-size: 1.1rem;
    }

    .user-text h4 {
      margin: 0;
      font-size: 0.95rem;
      font-weight: 600;
      color: white;
    }

    .user-text p {
      margin: 0;
      font-size: 0.8rem;
      opacity: 0.9;
      color: #e0f2fe;
    }

    .logout-btn {
      background: rgba(255,255,255,0.2);
      border: none;
      color: white;
      width: 32px;
      height: 32px;
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.3s ease;
    }

    .logout-btn:hover {
      background: rgba(255,255,255,0.3);
      transform: scale(1.1);
    }

    .student-menu{
      flex: 1;
    }

    .student-menu .item{
      display:flex;
      align-items:center;
      gap:12px;
      padding:12px 16px;
      border-radius:12px;
      color:#e0f2fe;
      text-decoration:none;
      margin:6px 0;
      transition: all 0.3s ease;
    }

    .student-menu .item i{
      width:20px;
      text-align:center;
      font-size:1.1rem;
    }

    .student-menu .item:hover{
      background:rgba(255,255,255,0.15);
      transform: translateX(5px);
    }

    .student-menu .item.active{
      background:white;
      color:var(--primary-dark);
      box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
    }

    .student-menu .item.active i{
      color:var(--primary-dark);
    }

    .points-display{
      background:rgba(255,255,255,0.15);
      border-radius:16px;
      padding:16px;
      margin:20px 0;
      text-align:center;
      border:2px dashed rgba(255,255,255,0.3);
    }

    .points-value{
      font-size:2rem;
      font-weight:800;
      color:white;
      margin:8px 0;
    }

    .points-label{
      font-size:0.9rem;
      opacity:0.9;
    }

    /* Logout form en el footer del sidebar */
    .sidebar-footer {
      margin-top: auto;
      padding-top: 20px;
      border-top: 1px solid rgba(255,255,255,0.2);
    }

    .logout-form {
      display: flex;
      align-items: center;
      gap: 12px;
      background: rgba(255,255,255,0.1);
      padding: 12px;
      border-radius: 12px;
      color: white;
    }

    .logout-form i {
      font-size: 1.1rem;
      opacity: 0.9;
    }

    .logout-form span {
      flex: 1;
      font-size: 0.9rem;
    }

    .logout-form button {
      background: rgba(255,255,255,0.2);
      border: none;
      color: white;
      padding: 6px 12px;
      border-radius: 8px;
      font-size: 0.8rem;
      transition: all 0.3s ease;
    }

    .logout-form button:hover {
      background: rgba(255,255,255,0.3);
    }

    /* MAIN CONTENT */
    .student-main{
      padding:20px 24px;
      background:var(--background);
    }

    .student-topbar{
      display:flex;
      align-items:center;
      justify-content:space-between;
      margin-bottom:24px;
      padding:16px 0;
    }

    .page-title{
      color:var(--primary-dark);
      font-weight:700;
      font-size:1.8rem;
      margin:0;
    }

    .welcome-message{
      color:var(--text-muted);
      font-size:1rem;
      margin-top:4px;
    }

    .action-buttons{
      display:flex;
      gap:12px;
      align-items:center;
    }

    .btn-scan{
      background:var(--secondary);
      color:white;
      border:none;
      padding:10px 20px;
      border-radius:12px;
      font-weight:600;
      display:flex;
      align-items:center;
      gap:8px;
      transition:all 0.3s ease;
    }

    .btn-scan:hover{
      background:#e58a08;
      transform:translateY(-2px);
    }

    .btn-redeem{
      background:var(--accent);
      color:white;
      border:none;
      padding:10px 20px;
      border-radius:12px;
      font-weight:600;
      display:flex;
      align-items:center;
      gap:8px;
      transition:all 0.3s ease;
    }

    .btn-redeem:hover{
      background:#2563eb;
      transform:translateY(-2px);
    }

    /* CARDS */
    .student-card{
      background:var(--card-bg);
      border-radius:16px;
      padding:20px;
      margin-bottom:20px;
      box-shadow:0 4px 12px rgba(0,0,0,0.05);
      border:1px solid var(--border);
    }

    .card-title{
      color:var(--primary-dark);
      font-weight:600;
      margin-bottom:16px;
      font-size:1.2rem;
    }

    /* BADGES */
    .badge-eco{
      background:var(--primary-light);
      color:var(--primary-dark);
      padding:6px 12px;
      border-radius:20px;
      font-weight:600;
      font-size:0.8rem;
    }
  </style>
</head>
<body>
<div class="student-layout">
  
  <aside class="student-sidebar">
    
    <a href="<?php echo e(route('estudiante.dashboard')); ?>" class="student-brand">
      <i class="fa-solid fa-recycle"></i>
      EcoRecicla PET
    </a>

    
    <div class="user-info-top">
      <div class="user-details">
        <div class="user-avatar">
          <i class="fa-solid fa-user-graduate"></i>
        </div>
        <div class="user-text">
          <h4><?php echo e(auth()->user()->nombre ?? 'Estudiante'); ?></h4>
          <p>Estudiante</p>
        </div>
      </div>
      <form method="POST" action="<?php echo e(route('logout')); ?>">
        <?php echo csrf_field(); ?>
        <button type="submit" class="logout-btn" title="Cerrar sesión">
          <i class="fa-solid fa-arrow-right-from-bracket"></i>
        </button>
      </form>
    </div>

    
    <div class="points-display">
      <div class="points-label">Tus Puntos</div>
      <div class="points-value"><?php echo e(auth()->user()->puntos ?? 0); ?></div>
      <div class="points-label">¡Sigue reciclando!</div>
    </div>

    <nav class="student-menu">
      
      <a class="item <?php echo e(request()->routeIs('estudiante.dashboard') ? 'active' : ''); ?>"
         href="<?php echo e(route('estudiante.dashboard')); ?>">
        <i class="fa-solid fa-house"></i> Inicio
      </a>

      
      <a class="item" href="#">
        <i class="fa-solid fa-qrcode"></i> Escanear Código
      </a>

      
      <a class="item" href="#">
        <i class="fa-solid fa-star"></i> Mis Puntos
      </a>

      
      <a class="item" href="#">
        <i class="fa-solid fa-gift"></i> Canjear Premios
      </a>

      
      <a class="item" href="#">
        <i class="fa-solid fa-history"></i> Mi Historial
      </a>

      
      <a class="item" href="#">
        <i class="fa-solid fa-trophy"></i> Mis Logros
      </a>

      
      <a class="item" href="#">
        <i class="fa-solid fa-user"></i> Mi Perfil
      </a>
    </nav>

    
    <div class="sidebar-footer">
      <form method="POST" action="<?php echo e(route('logout')); ?>" class="logout-form">
        <?php echo csrf_field(); ?>
        <i class="fa-solid fa-arrow-right-from-bracket"></i>
        <span>Cerrar sesión</span>
        <button type="submit">Salir</button>
      </form>
    </div>
  </aside>

  
  <main class="student-main">
    
    <div class="student-topbar">
      <div>
        <h1 class="page-title"><?php echo $__env->yieldContent('header', 'Mi Dashboard'); ?></h1>
        <div class="welcome-message">
          ¡Bienvenido de nuevo!
          <span class="badge-eco">+<?php echo e(auth()->user()->puntos ?? 0); ?> puntos</span>
        </div>
      </div>

      <div class="action-buttons">
        <button class="btn-scan">
          <i class="fa-solid fa-camera"></i> Escanear QR
        </button>
        <button class="btn-redeem">
          <i class="fa-solid fa-gift"></i> Canjear Puntos
        </button>
      </div>
    </div>

    
    <?php if(session('success')): ?>
      <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="fa-solid fa-check-circle me-2"></i>
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="fa-solid fa-exclamation-triangle me-2"></i>
        <?php echo e(session('error')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="fa-solid fa-exclamation-circle me-2"></i>
        <?php echo e($errors->first()); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    <?php endif; ?>

    
    <?php echo $__env->yieldContent('content'); ?>

  </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH D:\2025-Proyecto\2025-Proyecto\ecorecicla\resources\views/auth/estudiante/layout.blade.php ENDPATH**/ ?>