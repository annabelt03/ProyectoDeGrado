<?php $__env->startSection('content'); ?>
    <div class="card">
    <div class="card-body">
        <h4>Crear Usuario</h4>
        <form method="POST" action="<?php echo e(route('admin.usuarios.store')); ?>"><?php echo csrf_field(); ?>
        <div class="row g-3">
            <div class="col-md-6">
            <label class="form-label">Nombre *</label>
            <input name="nombre" class="form-control" required value="<?php echo e(old('nombre')); ?>">
            </div>
            <div class="col-md-6">
            <label class="form-label">Primer Apellido *</label>
            <input name="primerApellido" class="form-control" required value="<?php echo e(old('primerApellido')); ?>">
            </div>
            <div class="col-md-6">
            <label class="form-label">Segundo Apellido</label>
            <input name="segundoApellido" class="form-control" value="<?php echo e(old('segundoApellido')); ?>">
            </div>

            <!-- Campo RFID OBLIGATORIO -->
            <div class="col-md-6">
            <label class="form-label">Número RFID *</label>
            <input type="text" name="numeroRFID" class="form-control" required value="<?php echo e(old('numeroRFID')); ?>">
            <?php $__errorArgs = ['numeroRFID'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger small"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-6">
            <label class="form-label">Fecha Nacimiento</label>
            <input type="date" name="fechaNacimiento" class="form-control" value="<?php echo e(old('fechaNacimiento')); ?>">
            </div>
            <div class="col-md-6">
            <label class="form-label">Género</label>
            <select name="genero" class="form-select">
                <option value="">Seleccionar...</option>
                <option value="m" <?php if(old('genero')==='m'): echo 'selected'; endif; ?>>Masculino</option>
                <option value="f" <?php if(old('genero')==='f'): echo 'selected'; endif; ?>>Femenino</option>
            </select>
            </div>

            <!-- Campos condicionales para administrador -->
            <div id="campos-admin">
                <div class="col-md-6">
                <label class="form-label">Email * <small>(solo para admin)</small></label>
                <input type="email" name="email" id="email" class="form-control" value="<?php echo e(old('email')); ?>">
                </div>
                <div class="col-md-6">
                <label class="form-label">Password * <small>(solo para admin)</small></label>
                <input type="password" name="password" id="password" class="form-control">
                </div>
                <div class="col-md-6">
                <label class="form-label">Confirmar Password * <small>(solo para admin)</small></label>
                <input type="password" name="password_confirmation" id="password_confirmation" class="form-control">
                </div>
            </div>

            <div class="col-md-6">
            <label class="form-label">Rol *</label>
            <select name="role" id="role" class="form-select" required>
                <option value="estudiante" <?php if(old('role')==='estudiante'): echo 'selected'; endif; ?>>Estudiante</option>
                <option value="administrador" <?php if(old('role')==='administrador'): echo 'selected'; endif; ?>>Administrador</option>
            </select>
            </div>
        </div>
        <div class="mt-3">
            <button class="btn btn-primary">Guardar</button>
        </div>
        </form>
    </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const roleSelect = document.getElementById('role');
            const camposAdmin = document.getElementById('campos-admin');
            const emailInput = document.getElementById('email');
            const passwordInput = document.getElementById('password');
            const passwordConfirmationInput = document.getElementById('password_confirmation');

            function toggleAdminFields() {
                if (roleSelect.value === 'administrador') {
                    camposAdmin.style.display = 'block';
                    emailInput.required = true;
                    passwordInput.required = true;
                    passwordConfirmationInput.required = true;
                } else {
                    camposAdmin.style.display = 'none';
                    emailInput.required = false;
                    passwordInput.required = false;
                    passwordConfirmationInput.required = false;
                    emailInput.value = '';
                    passwordInput.value = '';
                    passwordConfirmationInput.value = '';
                }
            }

            // Ejecutar al cargar la página
            toggleAdminFields();

            // Ejecutar cuando cambie el rol
            roleSelect.addEventListener('change', toggleAdminFields);
        });
    </script>

    <style>
        #campos-admin {
            display: none;
            width: 100%;
        }
        #campos-admin .col-md-6 {
            display: block;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecorecicla\resources\views/auth/admin/usuarios/create.blade.php ENDPATH**/ ?>