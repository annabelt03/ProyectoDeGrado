<!-- resources/views/auth/admin/usuarios/index.blade.php  vista administrador -->



<?php $__env->startSection('title','Usuarios - EcoRecicla'); ?>
<?php $__env->startSection('header'); ?>
    <div>
        <h1 class="fw-bold text-success mb-1">Inicio</h1>
        <p class="fs-5 text-muted mb-0">
            Bienvenido al panel de administración de
            <strong>EcoRecicla PET</strong>
        </p>
    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
<div class="content-box">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h3>Gestión de Usuarios</h3>
    <div class="d-flex gap-2">
<a href="<?php echo e(route('admin.usuarios.create')); ?>" class="btn btn-success btn-sm">
    + Nuevo Usuario
</a>


</div>

  </div>

  <div class="table-responsive">
    <table class="table table-hover align-middle">
      <thead class="table-success">
      <?php if($role === 'usuario'): ?>
        <tr>
          <th>ID</th>
          <th>Nombre completo</th>
          <th>Código RFID</th>
          <th>Puntos</th>
          <th class="text-end">Acciones</th>
        </tr>
      <?php elseif($role === 'administrador'): ?>
        <tr>
          <th>ID</th>
          <th>Nombre completo</th>
          <th>Email</th>
          <th class="text-end">Acciones</th>
        </tr>
      <?php else: ?>
        
        <tr>
          <th>ID</th>
          <th>Nombre completo</th>
          <th>Rol</th>
          <th>Email</th>
          <th>Código RFID</th>
          <th>Puntos</th>
          <th class="text-end">Acciones</th>
        </tr>
      <?php endif; ?>
      </thead>

      <tbody>
      <?php $__empty_1 = true; $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php
          $nombreCompleto = trim($u->nombre.' '.$u->primerApellido.' '.($u->segundoApellido ?? ''));
        ?>

        <?php if($role === 'usuario'): ?>
          <tr>
            <td><?php echo e($u->id); ?></td>
            <td><?php echo e($nombreCompleto); ?></td>
            <td><?php echo e($u->numeroRFID ?? '—'); ?></td>
            <td><?php echo e($u->puntos ?? 0); ?></td>
            <td class="text-end">
              <a href="<?php echo e(route('admin.usuarios.show', $u)); ?>" class="btn btn-sm btn-info" title="Ver">
                <i class="fa-solid fa-eye"></i>
              </a>
              <a href="<?php echo e(route('admin.usuarios.edit', $u)); ?>" class="btn btn-sm btn-warning" title="Editar">
                <i class="fa-solid fa-pen-to-square"></i>
              </a>
              <form action="<?php echo e(route('admin.usuarios.destroy', $u)); ?>" method="POST" class="d-inline"
                    onsubmit="return confirm('¿Eliminar a <?php echo e($nombreCompleto); ?>?')">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button class="btn btn-sm btn-danger" title="Eliminar">
                  <i class="fa-solid fa-trash"></i>
                </button>
              </form>
            </td>
          </tr>

        <?php elseif($role === 'administrador'): ?>
          <tr>
            <td><?php echo e($u->id); ?></td>
            <td><?php echo e($nombreCompleto); ?></td>
            <td><?php echo e($u->email); ?></td>
            <td class="text-end">
              <a href="<?php echo e(route('admin.usuarios.show', $u)); ?>" class="btn btn-sm btn-info" title="Ver">
                <i class="fa-solid fa-eye"></i>
              </a>
              <a href="<?php echo e(route('admin.usuarios.edit', $u)); ?>" class="btn btn-sm btn-warning" title="Editar">
                <i class="fa-solid fa-pen-to-square"></i>
              </a>
              <form action="<?php echo e(route('admin.usuarios.destroy', $u)); ?>" method="POST" class="d-inline"
                    onsubmit="return confirm('¿Eliminar a <?php echo e($nombreCompleto); ?>?')">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button class="btn btn-sm btn-danger" title="Eliminar">
                  <i class="fa-solid fa-trash"></i>
                </button>
              </form>
            </td>
          </tr>

        <?php else: ?>
          
          <tr>
            <td><?php echo e($u->id); ?></td>
            <td><?php echo e($nombreCompleto); ?></td>
            <td><span class="badge bg-info text-dark"><?php echo e($u->role); ?></span></td>
            <td><?php echo e($u->email); ?></td>
            <td><?php echo e($u->numeroRFID ?? '—'); ?></td>
            <td><?php echo e($u->puntos ?? 0); ?></td>
            <td class="text-end">
              <a href="<?php echo e(route('admin.usuarios.show', $u)); ?>" class="btn btn-sm btn-info" title="Ver">
                <i class="fa-solid fa-eye"></i>
              </a>
              <a href="<?php echo e(route('admin.usuarios.edit', $u)); ?>" class="btn btn-sm btn-warning" title="Editar">
                <i class="fa-solid fa-pen-to-square"></i>
              </a>
              <form action="<?php echo e(route('admin.usuarios.destroy', $u)); ?>" method="POST" class="d-inline"
                    onsubmit="return confirm('¿Eliminar a <?php echo e($nombreCompleto); ?>?')">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button class="btn btn-sm btn-danger" title="Eliminar">
                  <i class="fa-solid fa-trash"></i>
                </button>
              </form>
            </td>
          </tr>
        <?php endif; ?>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td colspan="<?php echo e($role==='usuario' ? 5 : ($role==='administrador' ? 4 : 7)); ?>" class="text-center text-muted py-3">
            No hay usuarios
          </td>
        </tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>

  <?php echo e($usuarios->withQueryString()->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecorecicla\resources\views/auth/admin/usuarios/index.blade.php ENDPATH**/ ?>